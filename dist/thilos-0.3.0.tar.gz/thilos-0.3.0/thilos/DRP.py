"""
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <https://www.gnu.org/licenses/>.

Copyright (C) 2026 Gran Telescopio Canarias <https://www.gtc.iac.es>
Fabricio Manuel Pérez Toledo <fabricio.perez@gtc.iac.es>
"""

__author__="Fabricio M. Pérez-Toledo"
__version__ = "0.3.0"
__license__ = "GPL v3.0"

import thilos
from thilos.check_files import *
from thilos.reduction_hcam import *
from thilos.alignment_hcam import *

import argparse, time, os, shutil, sys
import json, warnings
from importlib.resources import files
from pathlib import Path

from thilos.Color_Codes import bcolors as bcl
from loguru import logger

warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=RuntimeWarning)


############## Predefined functions #############

def create_config_file_home():
    """
    This function creates a copy of the configuration file in .config/thilos
    / for easier accessibility.
    """
    with files('thilos').joinpath('config/configuration.json') as config_path: # type: ignore
        shutil.copy(config_path, Path(os.getcwd())/'configuration.json')
    logger.info(f"Configuration file created successfully in the current directory.")
    sys.exit()

def readJSON() -> json:
    """
    Reads the file containing the configuration parameters.

    Returns:
        json: Collection of configuration parameters 
    """
    return json.load(open(Path(os.getcwd())/'configuration.json'))


def run(path_config: str = None):
    """
    This function 
    """
    # Parse configuration
    parser = argparse.ArgumentParser(
                         prog = 'thilos',
                         description = 'This software reduces observations taken with HIPERCAM\
                            in Deep Field mode. It can process any filter configuration and is suitable\
                            for observations affected by fringing (Sloan_z).')

    parser.add_argument('-e', '--execute', help='Execute the configuration file in the current directory.',
                        action='store_true')
    
    parser.add_argument('-c', '--create_config', help='Create a configuration file in the current directory.',
                        action='store_true')
    
    parser.add_argument('-p', '--path_config', type=str, help='Path to the configuration file and raw data.',
                        default=None)

    args = parser.parse_args()


    print(f"{bcl.OKBLUE}***********************************************************************{bcl.ENDC}")
    print(f"{bcl.OKBLUE}************************* WELCOME TO THILOS **************************{bcl.ENDC}")
    print(f"{bcl.OKBLUE}***********************************************************************{bcl.ENDC}")
    print("\n")
    print(f"{bcl.BOLD}---------------------- LICENSE ----------------------{bcl.ENDC}")
    print("\n")
    print(f"This program is free software: you can redistribute it and/or modify\n\
it under the terms of the GNU General Public License as published by\n\
the Free Software Foundation, either version 3 of the License, or\n\
(at your option) any later version.\n\n\
This program is distributed in the hope that it will be useful,\n\
but WITHOUT ANY WARRANTY; without even the implied warranty of\n\
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the\n\
GNU General Public License for more details.\n\n\
You should have received a copy of the GNU General Public License\n\
along with this program. If not, see <https://www.gnu.org/licenses/>.")
    print("\n")
    print(f"{bcl.BOLD}************************ IMPORTANT INFORMATION ************************{bcl.ENDC}")
    print("\n")
    print(f"This software is designed to reduce Deep Field Imaging observations obtained with HIPERCAM.\n\
For proper use, you need to modify the configuration file, which can be found\n\
in the directory where this software is installed. Additionally, you need to create\n\
an account on Astrometry.net. Once you have the code that allows you to use the API,\n\
you need to fill in the correct variable.")
    print(f"\n")

    if args.create_config:
        logger.info(f"Creating configuration file...")
        logger.info(f"Configuration file created successfully in the current directory")
        create_config_file_home()
        sys.exit()

    conf = check_files(path_config=args.path_config)

    PRG = conf['PRG']
    OB = conf['OB']

    hora_local = time.localtime()
    print(conf)
    logger.add(Path(conf['DIRECTORIES']['PATH'])/f"thilos_{time.strftime('%Y-%m-%d_%H:%M:%S', hora_local)}.log", format="{time} {level} {message} ({module}:{line})", level="INFO",
            filter=lambda record: 'astropy' not in record["name"])
        
    logger.info(f'{bcl.OKGREEN}Log file created{bcl.ENDC}')
    logger.info(f'{bcl.OKGREEN}Configuration has been updated successfully{bcl.ENDC}')
    logger.info(f'{bcl.OKGREEN}Read the configuration file successfully{bcl.ENDC}')
    
    #Reduction Recipe. This recipe is responsible for cleaning the images by subtracting 
    #the masterbias and dividing by the normalized masterflat.
    #Subsequently, the cleaned images are saved.
    logger.info(f'{bcl.OKBLUE}---------- Starting the reductions for {PRG}-{OB} ----------{bcl.ENDC}')
    
    #Read the binning value from the configuration file.
    binning = conf['REDUCTION']['binning']

    # Is it valid?
    if binning not in [1, 2, 4]:
        logger.error(f'{bcl.FAIL}The binning value is not valid. Please check the configuration file{bcl.ENDC}')
        sys.exit()

    # Load the BPM files for each CCD concerning the binning value.
    list_bpms = []
    if conf['REDUCTION']['apply_BPM']:
        for ccd in range(1, 6):
            bpm_file = f"HCAM_BPM_CCD{ccd}_bin{binning}.fits"
            bpm_path = Path(conf['DIRECTORIES']['PATH_BPMs']) / bpm_file
            list_bpms.append(str(bpm_path))
    else:
        logger.warning(f'{bcl.WARNING}The BPM files are not going to be applied{bcl.ENDC}')
        list_bpms = None
        
    o = Reduction(main_path=conf['DIRECTORIES']['PATH_DATA'],
                path_mask=list_bpms)
    o.get_imagetypes()

    if conf['REDUCTION']['apply_BPM']:
        o.load_BPM()
    
    o.check_binning()
    o.sort_down_drawer()

    if conf['REDUCTION']['use_reduction'] and conf['REDUCTION']['use_BIAS']:
        o.do_masterbias()

    else:
        logger.warning(f'{bcl.WARNING}The masterbiases are not going to be created{bcl.ENDC}')

    if conf['REDUCTION']['use_reduction'] and conf['REDUCTION']['use_FLAT']:
        o.do_masterflat()

    else:
        logger.warning(f'{bcl.WARNING}The masterflats are not going to be created{bcl.ENDC}')
    
    if conf['REDUCTION']['use_reduction'] and conf['REDUCTION']['use_STD']:
        o.get_std(no_CRs=conf['REDUCTION']['no_CRs'], contrast_arg = conf['REDUCTION']['contrast'],
            cr_threshold_arg = conf['REDUCTION']['cr_threshold'],
            neighbor_threshold_arg = conf['REDUCTION']['neighbor_threshold'], apply_flat=conf['REDUCTION']['use_FLAT'],
            apply_BPM=conf['REDUCTION']['apply_BPM'])

    else:
        logger.warning(f'{bcl.WARNING}The STD star is not going to be reduced. It is likely not available{bcl.ENDC}')

    if conf['REDUCTION']['use_reduction']:
        o.get_target(no_CRs=conf['REDUCTION']['no_CRs'], contrast_arg = conf['REDUCTION']['contrast'],
                cr_threshold_arg = conf['REDUCTION']['cr_threshold'],
                neighbor_threshold_arg = conf['REDUCTION']['neighbor_threshold'], apply_flat=conf['REDUCTION']['use_FLAT'],
                apply_BPM=conf['REDUCTION']['apply_BPM'])

    if conf['REDUCTION']['use_reduction'] and conf['REDUCTION']['save_illumination_correction']:
            o.illumination_correction()
            logger.info(f'{bcl.OKGREEN}Illumination correction applied successfully{bcl.ENDC}')
    
    if conf['REDUCTION']['use_reduction'] and conf['REDUCTION']['defringing']:
        if conf['REDUCTION']['dithering']:
            logger.info(f'{bcl.OKBLUE}Dithering is enabled. Fringing correction will be applied using the dithering method{bcl.ENDC}')
            o.remove_fringing_dithering()
            logger.info(f'{bcl.OKGREEN}Fringing correction applied successfully using dithering method{bcl.ENDC}')
        else:
            logger.info(f'{bcl.OKBLUE}Dithering is disabled. Fringing correction will be applied using the no-dithering method{bcl.ENDC}')
            o.remove_fringing_no_dithering(path_fringe=conf['DIRECTORIES']['PATH_FRINGE'], binning=binning)
            logger.info(f'{bcl.OKGREEN}Fringing correction applied successfully using no-dithering method{bcl.ENDC}')
    else:
        logger.warning(f'{bcl.WARNING}The fringing correction is not going to be executed{bcl.ENDC}')

    if conf['REDUCTION']['use_reduction'] and conf['REDUCTION']['save_not_sky']:    
        o.sustract_sky()
        logger.info(f'{bcl.OKGREEN}The sky subtraction has been applied successfully{bcl.ENDC}')
    else:
        logger.warning(f'{bcl.WARNING}The sky substraction is not going to be executed{bcl.ENDC}')

    if conf['REDUCTION']['use_reduction']:
        o.save_target(std=conf['REDUCTION']['save_std'])
        o.save_target(std=conf['REDUCTION']['save_std'], fringing=conf['REDUCTION']['defringing'])
        o.save_target(sky=conf['REDUCTION']['save_sky'])
        o.save_target(fringing=conf['REDUCTION']['defringing'])    
        o.save_target(not_sky=conf['REDUCTION']['save_not_sky'])
    
        o.save_target(not_sky=conf['REDUCTION']['save_not_sky'],
                      fringing=conf['REDUCTION']['defringing'])

    if conf['REDUCTION']['use_reduction']:
        if not conf['REDUCTION']['defringing']:
            o.save_target(illumination=conf['REDUCTION']['save_illumination_correction'],
                          sky=conf['REDUCTION']['save_sky'])
        else:
            o.save_target(illumination=conf['REDUCTION']['save_illumination_correction'],
                          sky=conf['REDUCTION']['save_sky'],fringing=conf['REDUCTION']['defringing'])
    
    logger.info(f'{bcl.OKBLUE}-------------- End of the reductions successfully --------------{bcl.ENDC}')
    print(2*"\n")

    #Aligned Recipe. The cleaned science images are aligned based on the filter used in each case. 
    #Then, they are saved as aligned images.
    if conf['ALIGNING']['use_aligning']:
        logger.info(f"{bcl.OKBLUE}---------- Starting the alignments ----------{bcl.ENDC}")
        aligner = AstroImageAligner(min_snr=10.0, conf = conf)
        for filt in list(set(aligner.ic.summary['filtro'])):
            for sky in ['YES', 'NO']:
                if conf['REDUCTION']['save_not_sky'] or sky == 'YES':
                    logger.info(f'{bcl.OKCYAN}++++++++++ Aligment for {filt} & {o.dict_sky[sky]} ++++++++++{bcl.ENDC}')
                    aligner.run_aligning(filt, sky=sky)
                    header = aligner.ref_header.copy()
                    header['STACKED'] = (True, 'Stacked image')
                    header['exptime'] = aligner.ref_header['exptime'] * aligner.num
                    logger.info(f"Estimated total exposure time: {header['exptime']} sec")
                    wcs = aligner.ref_wcs.copy()
                    logger.info(f"Updating the WCS information")
                    if conf['ALIGNING']['defringing_stacked'] and ((filt == 'Sloan_i') or (filt == 'Sloan_z'))\
                        and not conf['REDUCTION']['dithering']:
                        logger.info(f"Applying fringing correction to stacked frame for {filt}")
                        masterfringe = fits.getdata(Path(conf['DIRECTORIES']['PATH_FRINGE']) / f"FRINGE_MAP_{filt}_{binning}x{binning}.fits")
                        aligner.stacked_image = defringe_no_dithering(aligner.stacked_image.data, masterfringe)['result']
                    save_fits(aligner.stacked_image, header, wcs, str(aligner.PATH_REDUCED / f'{PRG}_{OB}_{filt}_stacked_{o.dict_sky[sky]}.fits'))
                    
                else:
                    logger.warning(f'{bcl.WARNING}Alignments are not going to be executed for NOSKY{bcl.ENDC}')

        logger.info(f'{bcl.OKBLUE}------------------- End of the alignments -------------------{bcl.ENDC}')
        print(2*"\n")
    else:
        logger.warning(f'{bcl.WARNING}The alignments are not going to be executed{bcl.ENDC}')

if __name__ == '__main__':
    run()
